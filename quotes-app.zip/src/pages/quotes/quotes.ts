import { Quote } from './../../data/quote.interface';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the Quotes page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-quotes',
  templateUrl: 'quotes.html'
})
export class QuotesPage {

  quotes: Quote[];
  categoryTitle: string;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.quotes = navParams.data.quotes;
    this.categoryTitle = navParams.data.category;
  }

  onAddToFavorite() {
    
  }


}
